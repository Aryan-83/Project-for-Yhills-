let navbar = document.querySelector(".navbar");

// Navbar
document.querySelector("#MenuBars").onclick = () => {
  navbar.classList.toggle("active");
};

//Home Slider
var swiper = new Swiper(".homeSlider", {
  grabCursor: true,
  loop: true,
  centeredSlides: true,
});

// Gallery
$(".gallery .btn").click(function () {
  let filter = $(this).attr("data-filter");
  if (filter == "all") {
    $(".gallery .box").show(400);
  } else {
    $(".gallery .box")
      .not("." + filter)
      .hide(200);
    $(".gallery .box")
      .filter("." + filter)
      .show(400);

    $(this).addClass("buttonActive").siblings().removeClass("buttonActive");
  }
});

// Featured Section Start
$(".SmallOne img").click(function () {
  $(this).addClass("ImgActive").siblings().removeClass("ImgActive");

  let Images = $(this).attr("src");
  $(".LargeImg img").attr("src", Images);
});

// Theme Toggle
let ThemeToggle = document.querySelector(".themeToggle");
let ToggleBtn = document.querySelector(".ToggleBtn");

ToggleBtn.onclick = () => {
  ThemeToggle.classList.toggle("active");
};
document.querySelectorAll(".themeToggle .themeBtn").forEach((btn) => {
  btn.onclick = () => {
    let color = btn.style.background;
    document.querySelector(":root").style.setProperty("--main", color);
  };
});
